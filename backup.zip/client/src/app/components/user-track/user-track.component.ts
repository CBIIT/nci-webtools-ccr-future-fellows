import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-track',
  templateUrl: './user-track.component.html',
  styleUrls: ['./user-track.component.scss']
})
export class UserTrackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
