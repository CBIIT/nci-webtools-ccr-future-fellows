export const environment = {
  production: true,
  apiRoot: 'api',
};
